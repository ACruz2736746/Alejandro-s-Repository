/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Maximum/Minimum.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 23, 2021, 3:17 PM
 */

#include <iostream>
using std::cin;
using std::cout;

#include <iomanip>
using std::left;
using std::setw;
template <class Maximum>
Maximum greater(const Maximum &valOne, const Maximum &valTwo)
{
    if (valOne > valTwo)
    {
        return valOne;
    }
    else
    {
        return valTwo;
    }
}

/* **********************************************************
            template <class Minimum>
    Determines and returns the smaller of the two values.
   ********************************************************** */

template <class Minimum>
Minimum smaller(const Minimum &valOne, const Minimum &valTwo)
{
    if (valOne < valTwo)
    {
        return valOne;
    }
    else
    {
        return valTwo;
    }
}

void getMaximumVal();
void getMinimumVal();

int main()
{
    char tryAgain = ' ';

    cout << "MINIMUM / MAXIUM\n";
    cout << "Which value is greater, which is less?\n\n";

    do
    {
        getMaximumVal();
        getMinimumVal();

        cout << "Do you wish to try this again? ";
        cin >> tryAgain;

        while (toupper(tryAgain) != 'Y' && toupper(tryAgain) != 'N')
        {
            cout << "Do you wish to try this again? ";
            cin >> tryAgain;
        }
        cout << "\n";
    } while (toupper(tryAgain) != 'N');
   
    cout << "Thank you for trying this program. Have a nice day!\n";

    cin.ignore();
    cin.get();
   return 0;
}
void getMaximumVal()
{
    double maxDouble = 0.0;
    double maxDoubleOne = 0.0;
    char   maxChar = ' ';
    char   maxCharOne = ' ';

    cout << "Enter two floating-point values: ";
    cin >> maxDouble >> maxDoubleOne;

    cout << "Enter two characters: ";
    cin >> maxChar >> maxCharOne;

    cout << setw(26) << left << "\nThe greater value is:   "
          << greater(maxDouble, maxDoubleOne) << "\n";

    cout << "The greater character is: "
          << greater(maxChar, maxCharOne) << "\n\n";
}
void getMinimumVal()
{
    int  minInt = 0;
    int  minIntOne = 0;
    char minChar = ' ';
    char minCharOne = ' ';

    cout << "Enter two integer values: ";
    cin >> minInt >> minIntOne;

    cout << "Enter two characters: ";
    cin >> minChar >> minCharOne;

    cout << setw(25) << left << "\nThe lesser value is: "
          << smaller(minInt, minIntOne) << "\n";

    cout << "The lesser character is: "
          << smaller(minChar, minCharOne) << "\n\n";
}