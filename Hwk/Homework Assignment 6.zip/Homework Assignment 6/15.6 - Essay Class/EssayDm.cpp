/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Essay.h"

#include <iomanip>
using std::right;
using std::setw;

#include <iostream>
using std::cin;
using std::cout;

void getScores(int &, int &, int &, int &);
void displayGrade(const Essay &);

int main()
{
    int gr = 0;
    int sp = 0;
    int len = 0;
    int cont = 0;

    cout << "YAMAGATA 4th JUNIOR HIGH SCHOOL ESSAY GRADER\n\n";

    // Get the scores
    getScores(gr, sp, len, cont);

    // Create an Essay score object
    Essay essay(gr, sp, len, cont);
    essay.addScore();
   
    displayGrade(essay);

    cin.get();
    cin.ignore();
    return 0;
}
void getScores(int &gr, int &sp, int &len, int &cont)
{
    cout << "Enter the score for the following items:\n\n";
    cout << "Grammar (Max " << GRAMMAR << " points): ";
    cin >> gr;

    while (gr < 0 || gr > GRAMMAR)
    {
        cout << "Grammar: ";
        cin >> gr;
    }

    cout << "Spelling (Max " << SPELLING << " points): ";
    cin >> sp;

    while (sp < 0 || sp > SPELLING)
    {
        cout << "Spelling: ";
        cin >> sp;
    }

    cout << "Correct Length (Max " << SPELLING << " points): ";
    cin >> len;

    while (len < 0 || len > CORRECT_LENGTH)
    {
        cout << "Correct Length: ";
        cin >> len;
    }

    cout << "Content: (Max " << CONTENT << " points): ";
    cin >> cont;

    while (cont < 0 || cont > CONTENT)
    {
        cout << "Content: ";
        cin >> cont;
    }
}
void displayGrade(const Essay &essay)
{
    cout << "\n\nESSAY GRADER - SUMMARY\n\n";
    cout << "Essay Title: " << setw(10)
          << "ERASE BAD MEMORIES - KEEP GOOD ONES\n\n";

    cout << "GRAMMAR" << setw(14) << "SPELLING" << setw(12)
          << "LENGTH" << setw(14) << "CONTENT\n";
    cout << setw(7) << right << essay.getGrammarScore()
          << setw(14) << right << essay.getSpellingscore()
          << setw(12) << right << essay.getCorrectLengthScore()
          << setw(13) << right << essay.getContentScore() << "\n\n";

    cout << "Total  Score: " << essay.getScore() << "/100\n";
    cout << "Letter Grade: " << essay.getLetterGrade();
   
}
