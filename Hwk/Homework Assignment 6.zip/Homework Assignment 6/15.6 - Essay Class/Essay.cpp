/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Essay.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 8:00 PM
 */

#include "Essay.h"
void Essay::set(int gr, int sp, int len, int cont)
{
    grammar = gr;
    spelling = sp;
    length = len;
    content = cont;
}
void Essay::addScore()
{
    essayScore = grammar + spelling + length + content;

    setScore(essayScore);
}