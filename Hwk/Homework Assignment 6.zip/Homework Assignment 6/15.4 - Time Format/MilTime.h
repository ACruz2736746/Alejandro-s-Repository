/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MilTime.h
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 7:51 PM
 */

#ifndef MILTIME_H
#define MILTIME_H

#include "Time.h"

#include "string"
using std::string;

// MilTime class derived from the Time class
class MilTime : public Time
{
    protected:
        int milHours;            // Military hours (0 - 2359)
        int milSeconds;        // Military seconds (0 - 59)

    public:
        // Default Constructor
        MilTime() : Time()
        {
            milHours = 0;
            milSeconds = 0;
        }

        // Parameterized Constructor
        MilTime(int mHrs, int mSec) : Time(0, 0, 0)
        {
            setTime(mHrs, mSec);       
        }

        // Mutator functions
        bool isMilTime(const int, const int);
        void setTime(const int, const int);       
        void convertMilTime();

        // Accessor functions
        string getHour() const;
        string getStandHr() const;
};


#endif /* MILTIME_H */

