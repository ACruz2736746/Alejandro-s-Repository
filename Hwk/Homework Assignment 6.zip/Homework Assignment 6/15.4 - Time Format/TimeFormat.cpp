/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TimeFormat.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 7:54 PM
 */

#include "MilTime.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    int mHrs = 0;
    int mSecs = 0;

    cout << "MILITARY TIME CONVERTER\n\n";
    cout << "This program lets you convert Military to 'Standard' time.\n"
          << "Here is an example:\n\n";

    // Create a MilTime object and pass a military time to the constructor
    MilTime milTime(045, 7);
   
    cout << "MILITARY TIME\n";
    cout << milTime.getHour() << "\n\n";

    cout << "STANDARD TIME\n";
    cout << milTime.getStandHr() << "\n\n";

    // Create another MilTime object
    MilTime milTimeOne;

    // Ask the user to enter a military time
    cout << "Please enter a military time\n";
    cout << "Hour:   ";
    cin >> mHrs;
    cout << "Second: ";
    cin >> mSecs;
    cout << "\n";

    // Pass the values to the setTime() function of the MilTime class
    milTimeOne.setTime(mHrs, mSecs);

    cout << "MILITARY TIME\n";
    cout << milTimeOne.getHour() << "\n\n";

    cout << "STANDARD TIME\n";
    cout << milTimeOne.getStandHr() << "\n\n";

    cout << "Thank you for trying this program. Have a nice day!";

    cin.get();
    cin.ignore();
    return 0;
}

