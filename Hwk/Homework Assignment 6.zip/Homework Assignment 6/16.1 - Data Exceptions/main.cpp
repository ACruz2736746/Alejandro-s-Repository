/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 22, 2021, 8:04 PM
 */

#include "Date.h"

#include <array>
using std::array;

#include <iostream>
using std::cout;

#include <iostream>
using std::string;

// Initializes the daysPerMonth array with the days per month
const array<int, 13> daysPerMonth { 0, 31, 28, 31, 30, 31, 30,
                                    31, 31, 30, 31, 30, 31 };

// Initializes the monthNames array with the names of the months of the year
const array<string, 13> monthNames { "", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                                                 "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" };

enum Months { JANUARY = 1, FEBRUARY, MARCH, APRIL, MAY, JUNE,
              JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER };
              Date::Date()
{
    year = 1900;
    month = JANUARY;
    day = 1;
}
              void Date::setYear(int yyyy)
{
    if (yyyy >= 0 && yyyy <= 2200)
    {
        year = yyyy;
    }
     else
     {
         year = 1900;
     }
}
              void Date::setMonth(int mm)
{
    if (mm >= JANUARY && mm <= DECEMBER)
    {
        month = mm;
    }
    else
    {
         throw InvalidMonth(mm);
    }
}
              void Date::setDay(int dd)
{  
    if (month == FEBRUARY && isLeapYear() && dd == 29)
    {
        day = dd;
    }
    else if (dd < 1 || dd > daysPerMonth[month])
    {
        throw InvalidDay(dd);
    }
    else
    {
        day = dd;
    }
}
bool Date::isLeapYear()
{
    if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0))
    {
        return true;
    }

    return false;
}
void Date::getFormatOne() const
{
    cout << "\nSlash Style:\n";
    cout << month << "/" << day << "/" << year << "\n";
}
void Date::getFormatTwo() const
{
    cout << "\nU.S. Style:\n";
    cout << monthNames[month] << " " << day << ", " << year << "\n";
}
void Date::getFormatThree() const
{
    cout << "\nEuropean Style:\n";
    cout << day << " " << monthNames[month] << " " << year << "\n\n";
}
