/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Date.h
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 8:14 PM
 */

#ifndef DATE_H
#define DATE_H

class Date
{
    private:       
        int month;   
        int day;           
        int year;       

    public:       
        // Exception class
        class InvalidDay
        {
            private:
                int invalidDay;

            public:
                InvalidDay(int dayVal)
                { invalidDay = dayVal; }

                int getInvalidDay() const
                { return invalidDay; }
        };

        // Exception class
        class InvalidMonth
        {
            private:
                int invalidMonth;

            public:
                InvalidMonth(int monthVal)
                { invalidMonth = monthVal; }

                int getInvalidMonth() const
                { return invalidMonth; }
        };
       
        Date();

        // Mutator functions
        void setYear(int);
        bool isLeapYear();
        void setMonth(int);
        void setDay(int);

        // Accessor functions
        void getFormatOne() const;
        void getFormatTwo() const;
        void getFormatThree() const;
};

#endif /* DATE_H */

