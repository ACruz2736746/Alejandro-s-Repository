/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DateDm.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 8:20 PM
 */

#include "Date.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
   int  month = 0;
   int  day = 0;
   int  year = 0;
    bool tryAgain = true;

    Date dateObj;

   cout << "DATE EXCEPTION DEMO\n\n"
        << "This program lets you enter a date. If it is a valid date,\n"
        << "it is displayed in three formats.\n\n";
    cout << "Please enter a year, a month, and a day (Ex: 2008 02 29): ";
    cin >> year >> month >> day;

    dateObj.setYear(year);

    while (tryAgain)
    {
        try
        {       
            dateObj.setMonth(month);
            dateObj.setDay(day);

            cout << "\nThis is your date in three different formats:\n";
            dateObj.getFormatOne();
            dateObj.getFormatTwo();
            dateObj.getFormatThree();

            tryAgain = false;
        }
        catch (Date::InvalidDay dayVal)
        {
            cout << "\nError: Day " << dayVal.getInvalidDay() << " is invalid.\n";
            cout << "Please enter a valid day: ";
            cin >> day;
        }
        catch (Date::InvalidMonth monthVal)
        {
            cout << "\nError: Month " << monthVal.getInvalidMonth() << " does not exist.\n";
            cout << "Please enter a valid month: ";
            cin >> month;
        }
    }

    cout << "Thank you for trying the Date Exception Demo! Have a nice day!";

    cin.ignore();
   cin.get();
    return 0;
}
