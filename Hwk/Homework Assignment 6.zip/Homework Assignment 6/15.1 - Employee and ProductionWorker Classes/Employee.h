/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Employee.h
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 7:37 PM
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
using std::string;

class Employee
{
    private:
        string empName;                // Employee name
        int     empID;                    // Employee ID-number
        string empHireDate;            // Employee hire date
   
    public:   
        // Default constructor
        Employee()
        {
            empName = " ";
            empID = 0;
            empHireDate = " ";
        }

        // Parameterized constructor
        Employee(string name, int number, string hireDate)
        {
            empName = name;
            empID = number;
            empHireDate = hireDate;
        }

        // Mutator functions
        void setEmpName(string name)
        { empName = name; }

        void setEmpID(int number)
        { empID = number; }

        void setEmpHireDate(string hireDate)
        { empHireDate = hireDate; }

        // Accessor functions
        string getEmpName() const
        { return empName; }

        int getEmpID() const
        { return empID; }

        string getEmpDateHired() const
        { return empHireDate; }
};


#endif /* EMPLOYEE_H */

