/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   EmployeeProductionWorker
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 7:35 PM
 */

#include "ProductionWorker.h"

#include <iomanip>
using std::setprecision;
using std::setw;

#include <iostream>
using std::cin;
using std::cout;
using std::left;
using std::right;
using std::fixed;

void getEmployeeData(ProductionWorker &);
void outputData(const ProductionWorker &);

int main()
{
    // Create a ProductionWorker object
    ProductionWorker worker("Jane Moll", 938259, "05/04/1990", 1, 35.80);

    // Create another ProductionWorker object
    ProductionWorker workerOne;

    // Get data for this worker
    cout << "TAKEUCHI MANUFACTURING CO. - EMPLOYEE DATA ENTRY SYSTEM\n\n";
    getEmployeeData(workerOne);

    // Output data
    cout << "\n\nTAKEUCHI MANUFACTURING CO. - EMPLOYEE DATABASE\n\n";
    outputData(worker);
    outputData(workerOne);

    cout << "You are now leaving the Database System ...\n\n";
    cout << "TAKEUCHI MANUFACTURING CO.\n"
          << "Unrivaled quality, products with a difference,\n"
          << "and fast development responding to the users' needs.";

    cin.get();
    cin.ignore();
    return 0;
}

void getEmployeeData(ProductionWorker &worker)
{
    string name = " ";
    int    number = 0;
    string hireDate = " ";
    int    shift = 0;
    double payRate = 0.0;

    cout << "Enter employee name: ";
    getline(cin, name);
    worker.setEmpName(name);

    cout << "Enter employee ID: ";
    cin >> number;
    worker.setEmpID(number);

    cout << "Enter hire date (mm/dd/yyyy): ";
    cin >> hireDate;
    worker.setEmpHireDate(hireDate);

    cout << "\nEnter shift (1: Day, 2: Night): ";
    cin >> shift;
    worker.setShift(shift);

    cout << "Enter hourly pay rate: $ ";
    cin >> payRate;
    worker.setHourlyPayrate(payRate);
}
void outputData(const ProductionWorker &worker)
{
    cout << left  << setw(12) << "Name: "
          << right << worker.getEmpName() << "\n"
          << left  << setw(12) << "ID-Number: " 
          << right << worker.getEmpID() << "\n"
          << left  << setw(11) << "Date Hired: "
          << right << worker.getEmpDateHired() << "\n\n";

    worker.getShift() == 1 ? cout << "Assigned Shift: Day\n" :
                                     cout << "Assigned Shift: Night\n";
   
    cout << fixed << setprecision(2);
    cout << left << setw(12) << "Payrate: $ "
          << right << worker.getHourlyPayRate() << "\n\n";
}
