/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Patient.h
 * Author: Alejandro
 *
 * Created on July 20, 2021, 7:35 PM
 */

#ifndef PATIENT_H
#define PATIENT_H
#include <string>
using std::string;

class Patient
{
    private:
        string name;                    // Name of the patient
        string address;                // Patient's address
        string phoneNumber;            // Patient's telephone number
        string emcName;                // Name of the emergency contact person
        string emcPhoneNumber;        // Telephone number of the emergency contact person   

    public:
        // Constructor accepting arguments for all Procedure members
        Patient(string pN, string pAddr, string pPhone, string emcN, string emcPhone)
        {
            name = pN;
            address = pAddr;
            phoneNumber = pPhone;
            emcName = emcN;
            emcPhoneNumber = emcPhone;
        }
 // Destructor
        ~Patient()
        {}
         // Mutators
        void setName(string pN)
        { name = pN; }

        void setAddress(string pAddr)
        { address = pAddr; }
       
        void setPhoneNumber(string pPhone)
        { phoneNumber = pPhone; }

        void setEMCName(string emcN)
        { emcName = emcN; }

        void setEMCPhoneNumber(string emcPhone)
        { emcPhoneNumber = emcPhone; }

        // Accessors
        string getName() const
        { return name; }

        string getAddress() const
        { return address; }
       
        string getPhoneNumber() const
        { return phoneNumber; }

        string getEMCName() const
        { return emcName; }

        string getEMCPhoneNumber() const
        { return emcPhoneNumber; }

        void display() const;
};

#endif /* PATIENT_H */

