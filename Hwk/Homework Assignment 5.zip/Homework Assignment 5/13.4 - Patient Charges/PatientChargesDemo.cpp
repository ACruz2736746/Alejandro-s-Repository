/* File: Patient Charges Demo
 *  Author: Alejandro Cruz
 * Created: 7/20/21 - 7:46 pm
 */
#include <string>
#include <iostream>
#include <iomanip>
#include "Patient.h"
#include "Procdure.h"

using std::cout;
using std::cin;
using std::setw;

void calcCharges(Procedure &, const Procedure *, const int);
void displayInfo(const Procedure *, const int);

int main(){
    const int NUM_PROCEDURES = 3;

    Procedure charges;
    // Patient object initialized with
    Patient patientInfo("Lo Wen, Allen", "22 McKenzie Drive, Upper King, WA 6630",
                              "1244-124565", "Leona, Allen", "2484-241565");
// Array of three Procedure objects
    Procedure procedures[NUM_PROCEDURES] = { { "Physical Exam", "17.08.2017", "Dr. Irvine", 250.00 },
                                                          { "X-Ray", "17.08.2017", "Dr. Jones", 500.00 },
                                                          { "Blood Test", "17.08.2017", "Dr. Smith", 200.00 } };
   
    cout << "Mt. RAKUTEI HOSPITAL - PATIENT BILLING SYSTEM\n\n";

    patientInfo.display();
    calcCharges(charges, procedures, NUM_PROCEDURES);
    displayInfo(procedures, NUM_PROCEDURES);
    charges.displayTotal();

    cin.ignore();
    return 0;
}
void calcCharges(Procedure &charges, const Procedure *procedures, const int NUM_CHARGES)
{
    for (int i = 0; i < NUM_CHARGES; i++)
    {
        charges.setTotal(procedures[i].getCharge());               
    }
}
void displayInfo(const Procedure *procedures, const int NUM_PROCEDURES)
{
    cout << "MEDICAL PROCEDURES\n\n";
    cout << std::setprecision(2) << std::showpoint << std::fixed;
    for (int i = 0; i < NUM_PROCEDURES; i++)
    {
        procedures[i].display();
    }
}