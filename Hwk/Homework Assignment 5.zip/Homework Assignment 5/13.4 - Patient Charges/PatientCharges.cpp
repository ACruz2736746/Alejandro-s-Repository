/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Patient Charges
 * Author: Alejandro Cruz
 *
 * Created on July 20, 2021, 7:33 PM
 */

#include <iomanip>
#include <string>
#include "Procdure.h"
#include "Patient.h"
using std::cout;
using std::fixed;
using std::setprecision;
using std::showpoint;
using std::setw;


/*
 * 
 */
void Patient::display() const
{
         cout << "\n\nPATIENT INFORMATION\n\n"
              << "Patient Name: "     << setw(15) << getName()               << "\n"
                 << "Address: "          << setw(45) << getAddress()           << "\n"
                 << "Phone Number: "     << setw(13) << getPhoneNumber()    << "\n"
                 << "EMC Contact: "         << setw(15) << getEMCName()           << "\n"
                 << "EMC Phone #: "         << setw(14) << getEMCPhoneNumber() << "\n\n";
}
void Procedure::display() const
{
    cout << setw(16) << "Procedure Name: " << getProcedureName()        << "\n"
          << setw(16) << "Date: "               << getDateToday()            << "\n"
          << setw(16) << "Practitioner: "    << getPractitionerName() << "\n"
          << setw(18) << "Charge: $ "           << getCharge()               << "\n\n";
}
void Procedure::displayTotal() const
{
    cout << setw(18) << "Total Charge: $ " << total;
}


