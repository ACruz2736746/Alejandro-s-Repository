/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Procdure.h
 * Author: Alejandro Cruz
 *
 * Created on July 20, 2021, 7:38 PM
 */

#ifndef PROCDURE_H
#define PROCDURE_H
#include <string>
#include <iostream>
using std::string;

class Procedure
{
    private:
        string procedureName;            // Name of the procedure
        string dateToday;                    // Today's date
        string practitionerName;        // Name of the practitioner
        double charge;                        // Holding the charges for each procedure
        double total;                        // Holding the total charges

    public:
        // Default constructor
        Procedure()       
        {   
            procedureName = "";
            dateToday = "";
            practitionerName = "";
            charge = 0.0;
            total = 0.0;
        }

        // Destructor
        ~Procedure()
        {}

        // Constructor accepting arguments for all Procedure members
        Procedure(string procName, string dateT, string practName, double procChrg)   
        {
            procedureName = procName;
            dateToday = dateT;
            practitionerName = practName;
            charge = procChrg;
            total = procChrg;
        }

        // Mutators
        void setProcedureName(string proc)
        { procedureName = proc; }

        void setDateToday(string dateT)
        { dateToday = dateT; }

        void setPractitionerName(string practName)
        { practitionerName = practName; }

        void setTotal(double chrg)
        { total += chrg; }

        // Accessors
        string getProcedureName() const
        { return procedureName; }

        string getDateToday() const
        { return dateToday; }

        string getPractitionerName() const
        { return practitionerName; }

        double getCharge() const
        { return charge; }

        double getTotal() const
        { return total; }

        void display() const;
        void displayTotal() const;

};


#endif /* PROCDURE_H */

