/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 6:54 PM
 */

#include "InventoryClass.h"
#include <string>
#include <iostream>
bool Inventory::setItemNumber(int iID)
{
    if (iID > 0)
    {
        itemNumber = iID;
        return true;
    }
    else
    {
        std::cout << "\nInvalid item ID.\n\n";
    }

    return false;
}
bool Inventory::setQuantity(int iQty)
{
    if (iQty > 0)
    {
        quantity = iQty;
        return true;
    }
    else
    {
        std::cout << "\nItem quantity cannot be 0 or negative.\n\n";
    }

    return false;
}
bool Inventory::setCost(double iCost)
{
    if (iCost > 0)
    {
        cost = iCost;
        return true;
    }
    else
    {
        std::cout << "\nWholesale cost cannot be 0 or negative.\n";
    }

    return false;
}

void Inventory::setTotalCost(double iCost)
{
    totalCost = (quantity * iCost);
}