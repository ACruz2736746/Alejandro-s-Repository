/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "InventoryClass.h"
#include <iomanip>
#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::setw;
using std::setprecision;
using std::showpoint;
using std::fixed;

void getItemInfo(Inventory *, const int);
void displayItems(const Inventory *, const int);

int main()
{
    const int NUM_ITEMS = 2;
    Inventory items[NUM_ITEMS];

    cout << "CYBER CITY BATTLE-CHIP WAREHOUSE\n\n";

    getItemInfo(items, NUM_ITEMS);

    for (int i = 0; i < NUM_ITEMS; i++)
    {
        items[i].setTotalCost(items[i].getCost());
    }

    displayItems(items, NUM_ITEMS);

    cin.get();
    cin.ignore();
    return 0;
}
void getItemInfo(Inventory *items, const int NUM_ITEMS)
{
    int    itemID = 0;
    int    itemQuantity = 0;
    double itemCost = 0.0;

    for (int i = 0; i < NUM_ITEMS; i++)
    {
        cout << "Enter Item Number: " << setw(5) << "\n";
        cin >> itemID;
       
        while (!items[i].setItemNumber(itemID))
        {
            cout << "Enter Item Number: " << setw(5) << "\n";
            cin >> itemID;
        }

        cout << "Enter Quantity: " << setw(4) << "\n";
        cin >> itemQuantity;

        while (!items[i].setQuantity(itemQuantity))
        {
            cout << "Enter Quantity: " << setw(5) << "\n";
            cin >> itemQuantity;
        }

       cout << "Enter Wholesale Cost: " << setw(4) << "\n";
        cin >> itemCost;

        while (!items[i].setCost(itemCost))
        {
            cout << "Enter Wholesale Cost: " << setw(5) << "\n";
            cin >> itemCost;
        }
        cout << "\n";
    }
}
void displayItems(const Inventory *items, const int NUM_ITEMS)
{
    cout << "\nCYBER CITY BATTLE-CHIP WAREHOUSE\n\n"
         << setw(5)  << "Item ID"
          << setw(19) << "Units on Hand" << setw(16)
          << setw(13) << "Cost" << setw(13)
          << setw(20) << "Total Cost\n";
    cout << "==========================================================\n";

    for (int i = 0; i < NUM_ITEMS; i++)
    {
        cout << setw(7)  << items[i].getItemNumber()
              << setw(19) << items[i].getQuantity();
        cout << showpoint << fixed << setprecision(2);
        cout << setw(13) << items[i].getCost()
              << setw(19) << items[i].getTotalCost() << "\n";
    }
}