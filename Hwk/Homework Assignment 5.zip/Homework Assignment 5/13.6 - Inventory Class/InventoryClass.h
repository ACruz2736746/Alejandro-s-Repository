/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   InventoryClass.h
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:06 PM
 */

#ifndef INVENTORYCLASS_H
#define INVENTORYCLASS_H

class Inventory
{
    private:
        int itemNumber;      // The item number
        int quantity;             // Number of items on hand
        double cost;             // Wholesale per-unit cost of the item
        double totalCost;     // Total cost of the item

    public:
        // Default constructor
        Inventory()
        {
            itemNumber = 0;
            quantity = 0;
            cost = 0.0;
            totalCost = 0.0;
        }

        // Constructor accepting arguments for itemID, quantity and cost
        Inventory(int iID, int iQty, double iCost)
        {
            itemNumber = iID;
            quantity = iQty;
            cost = iCost;
        }

        // Mutators
        bool setItemNumber(int iID);
        bool setQuantity(int iQty);
        bool setCost(double iCost);
        void setTotalCost(double iCost);

        // Accessors
        int getItemNumber() const
        { return itemNumber; }

        int getQuantity() const
        { return quantity; }

        double getCost() const
        { return cost; }

        double getTotalCost() const
        { return totalCost; }   
};

#endif /* INVENTORYCLASS_H */

