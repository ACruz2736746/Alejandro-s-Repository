/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "DayOfTheYear.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    int number = 0;
    char again = ' ';

    cout << "\t\tDAY OF THE YEAR TO MONTH AND DAY TRANSLATOR\n\n";
    cout << "Please enter a day in the range of 1 through 365, and I will\n"
          << "translate it for you into a month and day format. For instance,\n"
          << "32 becomes February 1., and 230 translates to August 18.\n\n";

    do
    {
        cout << "Please enter a day (1 through 365): ";
        cin >> number;

        while (number <= 0 || number > 365)
        {
            cout << "Please enter a day (1 through 365): ";
            cin >> number;
        }

        // Create a DayOfYear class object
        DayOfYear day(number);
        day.print();

        cout << "\nWould you like me to translate another day (y/N)? ";
        cin >> again;

        while (toupper(again) != 'Y' && toupper(again) != 'N')
        {
            cout << "\nWould you like me to translate another day (y/N)? ";
            cin >> again;
        }
        cout << "\n";

        if (toupper(again) == 'N')
        {
            cout << "\nThank you for trying this demo program, have a nice day!";
        }
    } while (toupper(again) != 'N');

    cin.get();
    cin.ignore();
    return 0;
}