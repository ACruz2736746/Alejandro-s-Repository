/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 21, 2021, 7:19 PM
 */

#include "DayOfTheYear.h"

#include <iostream>
using std::cin;
using std::cout;

// Definition of const static array member holding month names
const string DayOfYear::monthOfYear[] = { "January", "February", "March", "April", "May", "June", "July",
                                                      "August", "September", "October", "November", "December" };

// Definition of const static array member holding a range of days
const int DayOfYear::daysInYear[] = { 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
void DayOfYear::print()
{
    bool isFound = false;
   
    for (int count = 0; count < NUM_MONTHS && isFound != true; count++)
    {
        if (day <= daysInYear[count])
        {
            cout << monthOfYear[count] << " " << (day %= daysInYear[count - 1]) << ".\n";
            isFound = true;
        }
    }
}