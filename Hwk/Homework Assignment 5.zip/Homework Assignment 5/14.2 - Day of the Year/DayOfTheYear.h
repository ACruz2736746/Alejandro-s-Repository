/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DayOfTheYear.h
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:27 PM
 */

#ifndef DAYOFTHEYEAR_H
#define DAYOFTHEYEAR_H

#include <string>
using std::string;

const int NUM_MONTHS = 12;

class DayOfYear
{
    private:
        const static string monthOfYear[NUM_MONTHS];
        const static int daysInYear[NUM_MONTHS];
       
        int day;                // To hold a day

    public:
        DayOfYear(int d)
        {
            day = d;
        }

        void print();
};

#endif /* DAYOFTHEYEAR_H */

