/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Date.h
 * Author: Alejandro Cruz
 *
 * Created on July 20, 2021, 6:53 PM
 */

#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>
using namespace std;
class Date {
private:
    int month, day, year;
    //Array of Month Names
    string monthNames[12] = {"January", "February", "March", "April", "May",
    "June", "July", "August", "September", "October", "November", "December"     
    };
public:
    //Constructor
    Date(int m = 1, int d = 1, int y = 1970){
        //Checks for invalid input for month
        if(m < 1 || m > 12){
            cout << "Error! Month can only be between 1 - 12!";
            cout << "Now terminating! \n";
            exit(EXIT_FAILURE);
        
    }
        //Check invalid input for day
        if(d < 1 || d > 31){
           cout << "Error! Day can only be between 1 - 31!";
            cout << "Now terminating! \n";
            exit(EXIT_FAILURE);
        }
        month = m;
        day = d;
        year = y;
    }
    //getter functions
    int getMonth(){
        return month;
    }
    int getDay(){
        return day;
    }
    int getYear(){
        return year;
    }
    //Setter functions
    void setMonth(int m){
        //Check for invalid input
        if(m < 1 || m > 12){
        cout << "Error! Month can only be between 1 - 31!";
            cout << "Now terminating! \n";
            exit(EXIT_FAILURE);    
        }
        else {
            month = m;
        }
    }
    void setDay(int d){
        //Check for invalid inputs
        if(d < 1 || d > 31){
            cout << "Error! Day can only be between 1 - 12!";
            cout << "Now terminating! \n";
            exit(EXIT_FAILURE);
        }
        else {
            day = d;
        }
    }
    void setYear(int y){
        year = y;
    }
    //Printing functions
    void format1(){
        cout << month << "/" << day << "/" << year;
            cout << endl;
    }
    void format2(){
        cout << monthNames[month-1] << " ";
            cout << day << ", " << year;
            cout << endl;
    }
    void format3(){
        cout << day << " " << monthNames[month-1];
        cout << " " << year;
            cout << endl;
    }
};



#endif /* DATE_H */

