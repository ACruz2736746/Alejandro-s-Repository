/* 
 * File:   13.1 - Date
 * Author: Alejandro Cruz
 *
 * Created on July 20, 2021, 6:49 PM
 */

#include <iostream>
#include <string>
#include "Date.h"

using namespace std;


int main() {
//Create a default data object
    Date obj1; //This will be Jan. 1, 1970
    //Create  and intialize a date object
    //with values of our choice
    Date obj2(5, 20, 2014); //This will be May 20, 2014
    //Print the first object in 3 ways
    obj1.format1();
    obj1.format2();
    obj1.format3();
    cout << endl;
    //Print the second object in 3 ways
    obj2.format1();
    obj2.format2();
    obj2.format3();
    cout << endl;
    
    return 0;
}

