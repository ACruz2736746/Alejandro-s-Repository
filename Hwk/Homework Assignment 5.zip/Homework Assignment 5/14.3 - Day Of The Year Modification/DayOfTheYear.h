/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DayOfTheYear.h
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 8:10 PM
 */

#ifndef DAYOFTHEYEAR_H
#define DAYOFTHEYEAR_H
#include <string>
using std::string;

const int NUM_MONTHS = 12;

class DayOfYear
{
    private:
        const static string monthOfYear[NUM_MONTHS];
        const static int daysInYear[NUM_MONTHS];
        const static int daysInMonth[NUM_MONTHS];
       
        string month;            // To hold a month name
        int day;                    // To hold a day
        int arrayIdx;            // Stores an array index

    public:
        DayOfYear()
        { }

        DayOfYear(int d);
        DayOfYear(string, int);
       
        bool isMonthName(string);
        void setMonth(int);
        void helpIncrement();
        void helpDecrement();
        void print();

        string getMonth() const
        { return month; }

        int getDay() const
        { return day; }

        DayOfYear operator++();
        DayOfYear operator++(int);
        DayOfYear operator--();
        DayOfYear operator--(int);
};



#endif /* DAYOFTHEYEAR_H */

