/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "DayOfTheYear.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    int day = 0;
    string monthName = "";

    cout << "\t\tDAY OF THE YEAR TO MONTH AND DAY TRANSLATOR\n\n";

    cout << "Please enter a month name: ";
    getline(cin, monthName);

    cout << "Now enter a day of this month: ";
    cin >> day;

    // Create a DayOfYear object to demonstrate the overloaded pre- and postfix ++ operators
    DayOfYear dayOne(monthName, day);

    cout << "\nThe month and day you entered is: ";
    dayOne.print();
    cout << "\n";
   
    cout << "\nThe next day will be: ";
    ++dayOne;
    dayOne.print();

    cout << "\nThe day after this will be: ";
    dayOne++;
    dayOne.print();

    cout << "\n\nNow enter a day in the range of 1 through 365, and I will\n"
          << "translate it for you into a month and day format: ";
    cin >> day;

    // Create a second DayOfYear object to demonstrate the overloaded pre- and postfix -- operators
    DayOfYear dayTwo(day);

    cout << "\nThe day you entered translates to: ";
    dayTwo.print();

    cout << "\n\nThe previous day was: ";
    (--dayTwo);
    dayTwo.print();
    cout << "\n";

    cout << "The day before this was: ";
    (dayTwo--);
    dayTwo.print();

    cout << "\n\nThank you for trying this demo, and have a nice day!\n"
          << "Please restart the program to try again!";

    cin.get();
    cin.ignore();
    return 0;
}
