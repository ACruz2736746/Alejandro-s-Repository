/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:32 PM
 */

#include "DayOfTheYear.h"

#include <iostream>
using std::cin;
using std::cout;

// Definition of const static array member holding month names
const string DayOfYear::monthOfYear[] = { "January", "February", "March", "April", "May", "June", "July",
                                                      "August", "September", "October", "November", "December" };
// Definition of const static array member holding a range of days
const int DayOfYear::daysInYear[] = { 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
const int DayOfYear::daysInMonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

DayOfYear::DayOfYear(int d)
{
    if (d >= 1 && d <= 365)
    {
        setMonth(d);

        if (d > 31)
        {
            d %= daysInYear[arrayIdx-1];
        }
        day = d;
    }
    else
    {
        cout << "\nInput failure: A normal year has at least 1 and no more than 365 days.\n";
        cout << "Please restart this program and try again!";
        cin.get();
        cin.ignore();
        exit(0);
    }
}
DayOfYear::DayOfYear(string m, int d)
{
    if (isMonthName(m) == true)
    {
        month = m;
    }
    else
    {
        cout << "\nInput failure: " << m << " does not exist\n";
        cout << "Please restart this program and try again!";
        cin.get();
        cin.ignore();
        exit(0);
    }
   
    if (d >= 1 && d <= daysInMonth[arrayIdx])
    {
        day = d;
    }
    else
    {
        cout << "\nInput failure: " << month << " starts with the 1.st, and has "
              << daysInMonth[arrayIdx] << " days.\n";
        cout << "Please restart this program and try again!";
        cin.get();
        cin.ignore();
        exit(0);
    }
}
void DayOfYear::setMonth(int d)
{
    bool isFound = false;

    for (int count = 0; count < NUM_MONTHS && isFound != true; count++)
    {
        if (d <= daysInYear[count])
        {
            arrayIdx = count;
            month = monthOfYear[count];
           
            isFound = true;
        }       
    }
}
bool DayOfYear::isMonthName(string m)
{
    for (int count = 0; count < NUM_MONTHS; count++)
    {
        if (m == monthOfYear[count])
        {
            arrayIdx = count;
            return true;
        }
    }
    return false;
}
void DayOfYear::helpIncrement()
{
    if (month == "December" && day == 31)
    {
        arrayIdx = 0;
        month = monthOfYear[arrayIdx];
        day = 0;
    }
    else if (day == daysInMonth[arrayIdx])
    {
        month = monthOfYear[++arrayIdx];
        day = 0;
    }
}
DayOfYear DayOfYear::operator++()
{
    helpIncrement();
    ++day;

    return *this;
}

DayOfYear DayOfYear::operator++(int)
{
    DayOfYear temp = *this;
   
    helpIncrement();
    day++;

    return temp;
}
DayOfYear DayOfYear::operator--()
{
    if (day == 1)
    {
        helpDecrement();
    }
    else
    {
        --day;
    }
    return *this;
}

DayOfYear DayOfYear::operator--(int)
{
    DayOfYear temp = *this;

    if (day == 1)
    {
        helpDecrement();
    }
    else
    {
        day--;
    }

    return temp;
}
void DayOfYear::print()
{
    cout << getMonth() << " " << getDay() << ".";
}