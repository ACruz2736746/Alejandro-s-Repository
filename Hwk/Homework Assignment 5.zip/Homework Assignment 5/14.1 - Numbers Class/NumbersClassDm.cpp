/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "Numbers.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    char again = ' ';            // Temporary variable holding a user's choice
    int tempNum = 0;            // Temporary variable to hold a number in an approriate range

    cout << "\tDOLLAR AMOUNT TO ENGLISH WORD CONVERTER\n";

    do
    {
        cout << "\nPlease enter a dollar amount in the range of 0 through 9999: ";
        cin >> tempNum;

        while (tempNum < 0 || tempNum > 9999)
        {
            cout << "\nInput Error!\n";
            cout << "Please enter a dollar amount in the range of 0 through 9999: ";
            cin >> tempNum;
        }

        // Create a Numbers class object
        Numbers number(tempNum);
        number.print();

        cout << "\nDo you wish to convert another dollar amount (y/N)? ";
        cin >> again;

        while (toupper(again) != 'Y' && toupper(again) != 'N')
        {
            cout << "\nDo you wish to convert another dollar amount (y/N)? ";
            cin >> again;
        }

        if (toupper(again) == 'N')
        {
            cout << "\nThank you for trying this demo program. Have a nice day!\n";
        }

    } while (toupper(again) == 'Y');


    cin.get();
    cin.ignore();
    return 0;
}
