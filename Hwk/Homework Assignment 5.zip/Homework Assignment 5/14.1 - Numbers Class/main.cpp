/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:14 PM
 */

#include "Numbers.h"

#include <iostream>
using std::cout;

// Definition of static string objects
string Numbers::zeroToTwenty[] = { "zero", "one", "two", "three", "four", "five", "six", "seven",
                                                 "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen",
                                                 "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };

string Numbers::tenMult[] = { "", "", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy",
                                        "eighty", "ninety" };

string Numbers::hundred = "hundred";
string Numbers::thousand = "thousand";
Numbers::Numbers(int n)
{
    number = n;
}
string Numbers::describeTens(int n)
{
    string tmpTens = "";

    if (n < 20)
    {
        return tmpTens = zeroToTwenty[n];
    }
    else if (n >= 20 && n % 10 == 0)
    {
        return tmpTens = tenMult[n / 10];
    }
    else
    {
        return tmpTens = tenMult[n / 10] + " " + zeroToTwenty[n % 10];
    }
}
void Numbers::print()
{
    string description = "";

    if (getNumber() < 100)
    {
        description.append(describeTens(getNumber()));
    }   
    else if (getNumber() < 1000)
    {
        description.append(zeroToTwenty[(getNumber() / 100)] + " " + hundred + " " +
                                 describeTens(getNumber() % 100));
    }
    if (getNumber() > 999)
    {
        description.append(zeroToTwenty[getNumber() / 1000] + " " + thousand + ", ");

        if (getNumber() % 1000 < 100)
        {
            description.append(describeTens(getNumber() % 1000));
        }
        else
        {
            description.append(zeroToTwenty[(getNumber() % 1000) / 100] + " " + hundred + " and " +
                                     describeTens(getNumber() % 100));
        }
    }
   
    cout << "\nThis is your dollar amount converted to English words:\n";
    cout << "----------------------------------------------------\n";
    cout << description << " dollar(s)\n";
}