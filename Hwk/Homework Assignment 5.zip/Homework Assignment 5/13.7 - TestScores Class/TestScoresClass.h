/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestScoresClass.h
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:11 PM
 */

#ifndef TESTSCORESCLASS_H
#define TESTSCORESCLASS_H

class TestScore
{
    private:
        int scoreOne;        // Score one
        int scoreTwo;        // Score two
        int scoreThree;    // Score three   
        double average;    // Average score

    public:
        TestScore()            // Default constructor
        {
            scoreOne = 0;
            scoreTwo = 0;
            scoreThree = 0;
            average = 0.0;
        }

        // Mutators
        void setScores(int scO, int scT, int scTh)
        {
                scoreOne = scO;
                scoreTwo = scT;
                scoreThree = scTh;
        }

        void setAverage()
        {
            average = (scoreOne + scoreTwo + scoreThree) / 3.0;   
        }

        // Accessors
        int getScoreOne() const
        { return scoreOne; }

        int getScoreTwo() const
        { return scoreTwo; }

        int getScoreThree() const
        { return scoreThree; }

        double getAverage() const
        { return average; }
};

#endif /* TESTSCORESCLASS_H */

