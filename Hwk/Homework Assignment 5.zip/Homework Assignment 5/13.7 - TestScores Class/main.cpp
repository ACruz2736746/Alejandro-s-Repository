/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 21, 2021, 7:10 PM
 */

#include "TestScoresClass.h"
#include <iomanip>
#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::setw;
using std::setprecision;
using std::showpoint;
using std::fixed;

void getScores(TestScore &);
void display(const TestScore);

int main()
{
    TestScore scores;

    cout << "AVERAGE TEST SCORE DEMO\n\n"
          << "Enter three test scores and I will calculate the average for you\n\n";

    getScores(scores);
    scores.setAverage();
    display(scores);

    cout << "\n\nThank you for trying this demo! Have a nice day.";
    cin.get();
    cin.ignore();
    return 0;
}

void getScores(TestScore &scores)
{
    int scoreO = 0;
    int scoreT = 0;
    int scoreTh = 0;

    cout << "Score 1: ";
    cin >> scoreO;

    while (scoreO < 1 || scoreO > 100)
    {
        cout << "Score 1: ";
        cin >> scoreO;
    }

    cout << "Score 2: ";
    cin >> scoreT;

    while (scoreT < 1 || scoreT > 100)
    {
        cout << "Score 2: ";
        cin >> scoreT;
    }

    cout << "Score 3: ";
    cin >> scoreTh;

    while (scoreTh < 1 || scoreTh > 100)
    {
        cout << "Score 3: ";
        cin >> scoreTh;
    }

    scores.setScores(scoreO, scoreT, scoreTh);
}
void display(const TestScore scores)
{
    cout << "\nThese are your test scores:\n\n";
    cout << "Score 1: " << scores.getScoreOne()   << "\n"
          << "Score 2: " << scores.getScoreTwo()   << "\n"
          << "Score 3: " << scores.getScoreThree() << "\n";

    cout << fixed << showpoint << setprecision(2);
    cout << "\nYou reached an average score of: " << scores.getAverage() << "%";
}