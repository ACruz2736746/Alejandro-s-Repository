/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Month.h
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 2:03 PM
 */

#ifndef MONTH_H
#define MONTH_H
#include <iostream>
using std::istream;
using std::ostream;

#include <string>
using std::string;

const int NUM_MONTHS = 13;

class Month
{
    private:
        static const string monthNames[NUM_MONTHS];        // Array holding month names

        string name;                        // To hold a month name
        int    monthNumber;                // To hold a month number (1 through 12)

    public:
        Month();
        Month(string);
        Month(int);

        void setMonthNumber(const int &);
        void setMonthName(const string &);

        string getMonthName() const
        { return name; }

        int getMonthNumber() const
        { return monthNumber; }

        // Overloaded operator functions
        Month operator++();                    // Prefix ++
        Month operator++(int);                // Postfix ++
        Month operator--();                    // Prefix --
        Month operator--(int);                // Postfix --

        // Friends
        friend ostream &operator << (ostream &, const Month &);
        friend istream &operator >> (istream &, Month &);
};



#endif /* MONTH_H */

