/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 2:03 PM
 */


#include "Month.h"

#include <iostream>
using std::cin;
using std::cout;

// Definition of const static array member holding month names
const string Month::monthNames[] = { "", "January", "February", "March", "April",
                                                 "May", "June", "July", "August", "September",
                                                 "October", "November", "December" };

Month::Month()
{
    name = "January";
    monthNumber = 1;
}
Month::Month(string n)
{
    setMonthName(n);
}
Month::Month(int mNum)
{
    setMonthNumber(mNum);
}
void Month::setMonthNumber(const int &mNum)
{
    if (mNum >= 1 && mNum <= 12)
    {
        monthNumber = mNum;
        name = monthNames[mNum];
    }
    else
    {
        monthNumber = 1;
        name = monthNames[monthNumber];
    }
}
void Month::setMonthName(const string &n)
{
    bool isFound = false;

    for (size_t count = 1; count < NUM_MONTHS; count++)
    {
        if (n == monthNames[count])
        {
            name = n;
            monthNumber = count;
            isFound = true;
        }   
    }

    if (isFound == false)
    {
        cout << "\nInput Error: " << n << " does not exist.\n"
             << "Setting month name and number to default values:\n\n";
        monthNumber = 1;
        name = monthNames[monthNumber];
       
    }
}
Month Month::operator++()
{
    ++monthNumber;

    getMonthNumber() <= 12 ? setMonthNumber(monthNumber) : setMonthNumber(1);

    return *this;
}

Month Month::operator++(int)
{
    Month temp(monthNumber);

    monthNumber++;
    getMonthNumber() <= 12 ? setMonthNumber(monthNumber) : setMonthNumber(1);

    return temp;
}

Month Month::operator--()
{
    --monthNumber;

    getMonthNumber() >= 1 ? setMonthNumber(monthNumber) : setMonthNumber(12);

    return *this;
}

Month Month::operator--(int)
{
    Month temp(monthNumber);

    monthNumber--;
    getMonthNumber() >= 1 ? setMonthNumber(monthNumber) : setMonthNumber(12);

    return temp;
}
istream &operator >> (istream &strm, Month &obj)
{
    strm >> obj.name;
    obj.setMonthName(obj.name);
   
    return strm;
}
ostream &operator << (ostream &strm, const Month &obj)
{
    return strm << obj.name << " is month number " << obj.monthNumber << ".";
}