/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MonthDm.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 2:07 PM
 */


#include "Month.h"

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    cout << "Months Class - Demo\n\n"
          << "This program demonstrates various functions of the Month class.\n\n"
          << "\t1.) The three constructors\n"
          << "\t2.) The overloaded pre- and postfix ++ and -- operators\n"
          << "\t3.) The overloaded istream and ostream operators\n\n"
          << "If a name or month number is invalid, their values are set\n"
          << "to: January and 1.\n\n";

    cout << "\tConstructor Demonstration\n\n";

    cout << "Demonstrating the default constructor\n";
    Month one;
    cout << one.getMonthName() << " is month number " << one.getMonthNumber() << "\n\n";

    cout << "Demonstrating the Second Constructor (Accepting a Month Name)\n";
    Month two("February");
    cout << two.getMonthName() << " is month number " << two.getMonthNumber() << "\n\n";

    cout << "Demonstrating the Third Constructor (Accepting a Mont Number)\n";
    Month three(9);
    cout << "Month " << three.getMonthNumber() << " is " << three.getMonthName() << "\n\n";

    cout << "\tOverloaded Post- and Prefix ++ and -- Operator Demonstration\n\n";
    cout << "Prefix ++\n";
    ++one;
    cout << one.getMonthName() << " is month number " << one.getMonthNumber() << "\n";

    cout << "Postfix ++\n";
    one++;
    cout << one.getMonthName() << " is month number " << one.getMonthNumber() << "\n\n";

    cout << "Prefix --\n";
    --two;
    cout << two.getMonthName() << " is month number " << two.getMonthNumber() << "\n";

    cout << "Postfix --\n";
    two--;
    cout << two.getMonthName() << " is month number " << two.getMonthNumber() << "\n\n";

    cout << "Overloaded Istream and Ostream Operator Demonstration\n\n";
    cout << "Enter a month name (January through December): ";
    Month four;
    cin >> four;
    cout << four;

    cin.get();
    cin.ignore();
    return 0;
}
