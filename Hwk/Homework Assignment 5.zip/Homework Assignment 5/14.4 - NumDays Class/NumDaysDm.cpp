/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "NumDaysClass.h"

#include <iomanip>
using std::fixed;
using std::showpoint;
using std::setprecision;

#include <iostream>
using std::cin;
using std::cout;

int main()
{
    NumDays thisWeek(26);
    NumDays lastWeek(15);
    NumDays total;

    cout << "YAMAGATA 4th JUNIOR HIGH SCHOOL BIWEEKLY WORKSHEET SUMMARY\n\n";

    // Demonstrating the overloaded postfix ++, -- operators
    cout << fixed << showpoint << setprecision(2);
    cout << "You worked " << thisWeek.getHours() << " hour(s) in total this week.\n";
    cout << "This makes " << thisWeek.getDays() << " day(s) of work.\n\n";

    cout << "We increased this amount by 1 hour\n";
    thisWeek++;
    thisWeek.print();

    cout << "We detected 1 hour from this amount\n";
    thisWeek--;
    thisWeek.print();

    // Demonstrating the overloaded prefix ++, --, + and - operators
    cout << "You worked " << lastWeek.getHours() << " hour(s) in total last week.\n";
    cout << "This makes " << lastWeek.getDays() << " day(s) of work.\n\n";

    cout << "We increased this amount by 1 hour\n";
    ++lastWeek;
    lastWeek.print();

    cout << "We detected 1 hour from this amount\n";
    --lastWeek;
    lastWeek.print();

    cout << "This week and last week you worked\n";
    total = thisWeek + lastWeek;
    total.print();

    cout << "The difference in hours and days is\n";
    total = thisWeek - lastWeek;
    total.print();

    cin.get();
    cin.ignore();
    return 0;
}
