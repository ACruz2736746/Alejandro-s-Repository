/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 22, 2021, 1:26 PM
 */

#include "NumDaysClass.h"

#include <iostream>
using std::cout;

NumDays NumDays::operator + (const NumDays &right)
{
    NumDays temp;
   
    temp.workHours = (workHours + right.workHours);

    return temp;
}
NumDays NumDays::operator - (const NumDays &right)
{
    NumDays temp;

    if (workHours < right.workHours)
    {
        temp.workHours = (right.workHours - workHours);
    }
    else
    {
        temp.workHours = (workHours - right.workHours);
    }
    return temp;
}
NumDays NumDays::operator ++()
{
    return ++workHours;
}
NumDays NumDays::operator ++(int)
{
    return workHours++;
}
NumDays NumDays::operator --()
{
    return --workHours;
}
NumDays NumDays::operator --(int)
{
    return workHours--;
}

void NumDays::print()
{
    cout << "Total: " << (getHours()) << " hour(s) or "
          << getDays() << " day(s).\n\n";
}