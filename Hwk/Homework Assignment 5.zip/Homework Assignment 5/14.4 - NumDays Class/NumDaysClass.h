/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NumDaysClass.h
 * Author: Alejandro Cruz
 *
 * Created on July 22, 2021, 1:30 PM
 */

#ifndef NUMDAYSCLASS_H
#define NUMDAYSCLASS_H
class NumDays
{
private:
    double workHours;            // To hold a number of hours

public:
    NumDays(double hours = 0.0)       
    {    workHours = hours; }

    void setHours(double hours)       
    { workHours = hours; }

    void print();

    double getHours() const
    { return workHours; }

    double getDays() const
    { return workHours / 8; }

    // Overloaded operator functions
    NumDays operator + (const NumDays &);                // Overloaded +
    NumDays operator - (const NumDays &);                // Overloaded -
    NumDays operator ++();                                    // Overloaded Prefix ++                       
    NumDays operator ++(int);                                // Overloaded Postfix ++
    NumDays operator --();                                    // Overloaded Prefix --
    NumDays operator --(int);                                // Overloaded Postfix --
};



#endif /* NUMDAYSCLASS_H */

