/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Review Homework 1 - 3.12
 * Author: Alejandro Cruz
 *
 * Created on June 24, 2021, 4:31 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    Temperature t;
    float f;
    cout <<"Enter Temperature in Fahrenheit =";
    cin >> f;
    
    cout <<"Temperature in Celsius =" << t.conversion(f);
    return 0;
}

class Temperature {
private:
    float farhen, celsius;
public:
    float conversion(float f) {
        farhen = f;
        celsius = (farhen - 32)*9.0/5.0;
        return celsius;
    }
};