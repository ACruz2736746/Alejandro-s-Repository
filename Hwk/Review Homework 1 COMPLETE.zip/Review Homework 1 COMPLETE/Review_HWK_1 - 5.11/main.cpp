/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Review HWK 1 - 5.11
 * Author: Alejandro Cruz
 *
 * Created on June 25, 2021, 12:01 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    float startPopulation = 0.0f;
    int numDays = 0;
    float avgIncrease = 0.0f;
    float dailyPopulation = 0.0f;
    
    cout << "Please enter starting number of organisms: ";
    cin >> startPopulation;
    
    while (startPopulation < 2) {
        cout << "The start population cannot be less than 2, please re-enter: ";
        cin >> startPopulation;
    }
    cout << "Please enter the number of days the population multiplies: ";
    cin >> numDays;
    
    while (numDays < 1) {
        cout << "The number of days cannot be less than 1, please re-enter: ";
        cin >> numDays;
    }
    cout << "Please enter average daily increase in population (in percentages): ";
    cin >> avgIncrease;
    
    while (avgIncrease < 0) {
        cout << "The average increase in population cannot be negative, please re-enter: ";
        cin >> avgIncrease;
    }
    
    for (int i = 1; 1 <= numDays; 1++) {
        dailyPopulation = ((avgIncrease / 100) * startPopulation) + startPopulation;
        cout << "Population for day" << i << "is" << dailyPopulation << endl;
        startPopulation = dailyPopulation;
    }
    return 0;
}

