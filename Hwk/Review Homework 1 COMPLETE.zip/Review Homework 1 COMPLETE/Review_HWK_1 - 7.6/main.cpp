/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Review HWK 1 - 7.6
 * Author: Alejandro Cruz
 *
 * Created on June 25, 2021, 2:43 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

    int sum(int arr[], const int SIZE);
    int indexOfMax( int arr[], const int SIZE);
   
    int main(){
        cout<<"============================================\n";
        cout<<"\t     :: Information ::\n";
        cout<<"This program reads some  data  from  a  file\n";
        cout<<"about weather conditions collected over  the\n";
        cout<<"past summer months: June, July, and  August.\n";
        cout<<"It would then display some  statistics  der-\n";
        cout<<"ived by the collected data.\n";
        cout<<"============================================\n";
        
        const int NUM_MONTHS = 3;
        const int NUM_DAYS   = 30;
        char reading;              
        int  rainy[NUM_MONTHS] = {0};      
        int cloudy[NUM_MONTHS] = {0};      
        int  sunny[NUM_MONTHS] = {0};      
        char data[NUM_MONTHS][NUM_DAYS];   
        
        ifstream reader("report.txt");
        if(!reader){
            cout<<"Some error happened while opening the file.\n";
            return 0;
        }
        
        for(int month = 0; month < NUM_MONTHS; month++){
            for(int day = 0; day < NUM_DAYS; day++){
                if( reader>>reading ){
                    switch(reading){
                        case 'R':
                            rainy[month]++;
                            break;
                        case 'C':
                            cloudy[month]++;
                            break; 
                        case 'S':
                            sunny[month]++;
                            break;
                        default:
                            cout<<"Wrong format.\n";
                            cout<<"The program would terminate.\n";
                            reader.close();
                            return 0;
                    }
                   
                    data[month][day] = reading;
                }else{
                    cout<<"Incomplete readings,\n";
                    cout<<"The program would terminate.\n";
                    reader.close();
                    return 0;
                }
            }
        }
        cout<<"Statistics have been gathered from the data.\n";
        cout<<"============================================\n";
        cout<<"Here is the gathered statistics,\n";
        
        for(int month = 0; month < NUM_MONTHS; month++){
            cout<<" The number of rainy days of month "<<month+6
                <<" : "<<rainy[month]<<std::endl;
        }
        cout<<"      The total number of rainy days : "
            <<sum(rainy, NUM_MONTHS)<<std::endl;
        
        cout<<"<><><><><><><><><><><><><><><><><><><><><><>\n";
        
        for(int month = 0; month < NUM_MONTHS; month++){
            cout<<"The number of cloudy days of month "<<month+6
                <<" : "<<cloudy[month]<<std::endl;
        }
        cout<<"     The total number of cloudy days : "
            <<sum(cloudy, NUM_MONTHS)<<std::endl;
        
        cout<<"<><><><><><><><><><><><><><><><><><><><><><>\n";
        
        for(int month = 0; month < NUM_MONTHS; month++){
            cout<<" The number of sunny days of month "<<month+6
                <<" : "<<sunny[month]<<std::endl;
        }
        cout<<"      The total number of sunny days : "
            <<sum(sunny, NUM_MONTHS)<<std::endl;
            
        cout<<"--------------------------------------------\n";
        
        cout<<" The "<<indexOfMax(rainy,NUM_MONTHS)+6
            <<"th month had the largest rainy days.\n";
        cout<<"The "<<indexOfMax(cloudy,NUM_MONTHS)+6
            <<"th month had the largest cloudy days.\n";
        cout<<" The "<<indexOfMax(sunny,NUM_MONTHS)+6
            <<"th month had the largest sunny days.\n";
        
        cout<<"============================================\n";
        
        reader.close();
        return 0;
    }
    
    
    int sum(int arr[], const int SIZE){
        int total = 0;
        for(int i=0; i<SIZE; i++){
            total += arr[i];
        }
        return total;
    }
    
   
    int indexOfMax(int arr[], const int SIZE){
        int indexMax = 0;
        for(int i=1; i<SIZE; i++){
            if(arr[indexMax] < arr[i]){
                indexMax = i;
            }
        }
 
        return indexMax;
    }
   