/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Review HWK 1 - 3.13
 * Author: Alejandro Cruz
 *
 * Created on June 24, 2021, 5:09 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    const float YEN_PER_DOLLAR = 111.11,
            EUROS_PER_DOLLAR = .85;
    
    float user_amount, dollar_to_yen, dollar_to_euro;
    
    cout << endl;
    cout << "Enter US dollar amount: ";
    cin >> user_amount;
    
    dollar_to_yen = user_amount * YEN_PER_DOLLAR;
    dollar_to_euro =user_amount * EUROS_PER_DOLLAR;
    
    cout << setprecision(2) << fixed << endl;
    cout<< "Dollar amount = $" << user_amount;
    cout << "\nYen amount= ¥" << dollar_to_yen;
    cout << "\nEuro  amount = €" << dollar_to_euro;
    cout << '\n' << endl;
    
    return 0;
}

