/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Review HWK 1 - 4.10
 * Author: Alejandro Cruz
 *
 * Created on June 24, 2021, 7:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    int month, year;
    
    cout <<"Enter month (1-12): ";
    cin >> month;
    cout << endl; << "Enter year: ";
    cin >> year;
    
    switch (month){
        case 1: 
            cout << "There are 31 days in this month.";
            break;
        case 2:
            if(year % 100 == 0)
                if(year % 400 == 0)
                    cout << "There are 29 days in this month.";
                else
                    cout << "There are 28 days in this month.";
            else if(year % 4 == 0)
                cout << "There are 29 days in this month.";
            else
                cout << "There are 28 days in this month.";
            break;
        case 3: 
            cout << "There are 31 days in this month.";
            break;
        case 4:
            cout << "There are 30 days in this month.";
            break;
        case 5:
            cout << "There are 31 days in this month.";
            break;
        case 6:
            cout << "There are 30 days in this month.";
            break;
        case 7:
            cout << "There are 31 days in this month.";
            break;
        case 8:
            cout << "There are 31 days in this month.";
            break;
        case 9:
            cout << "There are 30 days in this month.";
            break;
        case 10:
            cout << "There are 31 days in this month.";
            break;
        case 11:
            cout << "There are 30 days in this month.";
            break;
        case 12: 
            cout << "There are 31 days in this month.";
            break;
    }
    return 0;
}

