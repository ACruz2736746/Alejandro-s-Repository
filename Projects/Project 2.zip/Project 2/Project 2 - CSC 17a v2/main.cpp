/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 27, 2021, 4:01 PM
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Yahtzee - Project 2 - CSC 17a v2
 * Author: Alejandro Cruz
 * Created on July 25, 2021, 9:05 PM
 */

#include <iostream>
#include "RollingDiceV2.h"

using namespace std;

/*
 * 
 */
int main() {
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice1();
    cout << "Want to Roll again?"
            cin >> RollDice1(1);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice2();
    cout << "Want to Roll again?"
            cin >> RollDice2(2);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice3();
    cout << "Want to Roll again?"
            cin >> RollDice3(3);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice4();
    cout << "Want to Roll again?"
            cin >> RollDice4(4);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice5();
    cout << "Want to Roll again?"
            cin >> RollDice5(5);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice6();
    cout << "Want to Roll again?"
            cin >> RollDice6(6);
    return 0;
}

double division(int a, int b) {
   if( b == 0 ) {
      throw "Here is the exception";
   }
   return (a/b);
}

class rollIf {
   public:
      void print(int i) {
        cout << "Printing one of the numbers: " << i << endl;
      }
      void print(double  f) {
        cout << "Printing more results: " << f << endl;
      }
      void print(char* c) {
        cout << "Printing character of Dice: " << c << endl;
      }
};
