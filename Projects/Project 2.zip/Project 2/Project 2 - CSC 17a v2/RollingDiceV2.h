/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   RollingDiceV2.h
 * Author: Alejandro Cruz
 *
 * Created on July 27, 2021, 4:04 PM
 */

#ifndef ROLLINGDICEV2_H
#define ROLLINGDICEV2_H


class RollingDice {
    RollDice1();
    RollDice2();
    RollDice3();
    RollDice4();
    RollDice5();
    RollDice6();
    
    public:
    int Dice();
private: 
    int memNum(int *, int);
};

class cube: public Dice {
   public:
      int getScore() { 
         return (width * height); 
      }
};

#endif /* ROLLINGDICEV2_H */

