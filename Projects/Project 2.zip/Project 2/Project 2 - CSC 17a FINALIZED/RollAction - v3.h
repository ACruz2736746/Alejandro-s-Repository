/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   RollAction - v3.h
 * Author: Alejandro Cruz
 *
 * Created on July 28, 2021, 4:17 PM
 */

#ifndef ROLLACTION___V3_H
#define ROLLACTION___V3_H

class RollingDice {
    RollDice1();
    RollDice2();
    RollDice3();
    RollDice4();
    RollDice5();
    RollDice6();
    
    public:
    int Dice();
private: 
    int memNum(int *, int);
};

class cube: public Dice {
   public:
      int getScore() { 
         return (width * height); 
      }
};

template <typename D>
D numMax (D x, D y){
    return (x > y)? x: y;
}

#endif /* ROLLACTION___V3_H */

