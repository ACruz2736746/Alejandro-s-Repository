/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 28, 2021, 4:15 PM
 */

#include <iostream>

#include "RollAction - v3.h"

using namespace std;

/*
 * 
 */
int main() {
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice1();
    cout << "Want to Roll again?"
            cin >> RollDice1(1);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice2();
    cout << "Want to Roll again?"
            cin >> RollDice2(2);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice3();
    cout << "Want to Roll again?"
            cin >> RollDice3(3);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice4();
    cout << "Want to Roll again?"
            cin >> RollDice4(4);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice5();
    cout << "Want to Roll again?"
            cin >> RollDice5(5);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice6();
    cout << "Want to Roll again?"
            cin >> RollDice6(6);
    return 0;
}

double division(int a, int b) {
   if( b == 0 ) {
      throw "Here is the exception";
   }
   return (a/b);
}

class rollIf {
   public:
      void print(int i) {
        cout << "Printing one of the numbers: " << i << endl;
      }
      void print(double  f) {
        cout << "Printing more results: " << f << endl;
      }
      void print(char* c) {
        cout << "Printing character of Dice: " << c << endl;
      }
};
 float diceMultiplier = 3;
void turnAbout {
    cout << numMax<int>(3, 7) << endl;  
  cout << numMax<double>(3.0, 7.0) << endl; // call numMax for double
  cout << numMax<char>('g', 'e') << endl;   // call numMax for char
  cout << "You got a multiplier!!" << "x3";
cin >> diceMultiplier;
}
// Does more with multiplier
int moreMulti{
    diceMultiplier +5
            numMax.RollDice1
            numMax.RollDice2
            numMax.RollDice3
            numMax.RollDice4
            numMax.RollDice5
            numMax.RollDice6
            cout << "Here multiple max numbers of roll"
}

char well = i++;

