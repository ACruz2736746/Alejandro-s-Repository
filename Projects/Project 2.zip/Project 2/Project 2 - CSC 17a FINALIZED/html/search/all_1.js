var searchData=
[
  ['rollif_1',['rollIf',['../classroll_if.html',1,'']]],
  ['rollingdice_2',['RollingDice',['../class_rolling_dice.html',1,'']]]
];
