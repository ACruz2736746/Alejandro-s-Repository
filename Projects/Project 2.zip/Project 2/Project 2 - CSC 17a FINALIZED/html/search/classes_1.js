var searchData=
[
  ['rollif_4',['rollIf',['../classroll_if.html',1,'']]],
  ['rollingdice_5',['RollingDice',['../class_rolling_dice.html',1,'']]]
];
