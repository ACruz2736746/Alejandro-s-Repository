/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Yahtzee - Project 2 - CSC 17a
 * Author: Alejandro Cruz
 * Created on July 25, 2021, 9:05 PM
 */

#include <iostream>
#include "RollingAction.h"
#include <csstidb>
using namespace std;

/*
 * 
 */
int main() {
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice1();
    cout << "Want to Roll again?"
            cin >> RollDice1(1);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice2();
    cout << "Want to Roll again?"
            cin >> RollDice2(2);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice3();
    cout << "Want to Roll again?"
            cin >> RollDice3(3);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice4();
    cout << "Want to Roll again?"
            cin >> RollDice4(4);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice5();
    cout << "Want to Roll again?"
            cin >> RollDice5(5);
    cout << "Ready To Roll? Enter Roll:" << endl;
    cin >> RollDice6();
    cout << "Want to Roll again?"
            cin >> RollDice6(6);
    return 0;
}

double division(int a, int b) {
   if( b == 0 ) {
      throw "Here is the exception";
   }
   return (a/b);
}