/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   RollingAction.h
 * Author: Alejandro Cruz
 *
 * Created on July 25, 2021, 9:19 PM
 */

#ifndef ROLLINGACTION_H
#define ROLLINGACTION_H
public:
    int Dice();
private: 
    int memNum(int *, int);
class RollingDice {
    RollDice1();
    RollDice2();
    RollDice3();
    RollDice4();
    RollDice5();
    RollDice6();
};


#endif /* ROLLINGACTION_H */

