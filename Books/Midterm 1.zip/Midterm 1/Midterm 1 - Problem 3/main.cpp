
/* 
 * File:  Midterm 1 - Problem 3
 * Author: Alejandro Cruz
 *
 * Created on July 14, 2021, 2:21 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */

Stats *stat(const Array *array){
    //Non-working stub to be completed by the student
    cout<<endl<<"stat function to be completed by the student"<<endl;
    Stats *stats=new Stats;
    stats->mode=new Array;
    stats->mode->size=0;
    int nModes=0;
    stats->mode->data=new int[nModes];
    stats->modFreq=0;
    stats->median=0;
    return stats;
}
// Delcaring some variables
void Stats;
int i = 0;
float mode = i/2;
float modeFreq = i++;
float median = i * 2/i++;


int main(int argc, char** argv) {
   
    
    return 0;
}

