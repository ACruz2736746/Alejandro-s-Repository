/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Midterm 1 - Problem 1
 * Author: Alejandro Cruz
 *
 * Created on July 13, 2021, 9:23 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */

struct Customer {
    void accNum;
    float address;
    void balance;
    float total;
};

int main(int argc, char** argv) {
    cout << " Enter the Account Number: ";
    cin >> accNum;
    
    cout << "Enter the address: " << endl;
    cin >> address;
    
    cout << "Enter the balance: " << endl;
    cin >> balance;
    
    cout << "The total: " << endl;
    cin >> balance + total;
    
    
    return 0;
}

