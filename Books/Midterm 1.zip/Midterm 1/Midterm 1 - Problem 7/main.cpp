/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:  Midterm 1 - Problem 7
 * Author: Alejandro Cruz
 * 
 *
 * Created on July 16, 2021, 2:59 PM
 */

#include <iostream>

using namespace std;

struct Prime{
	unsigned short prime;
	unsigned char power;
};
struct Primes{
	unsigned char nPrimes;
	Prime *prime;
};

int main(int argc, char** argv) {
Primes *factor(int);
void prntPrm(Primes *);

cout << "Enter the number" << endl;
cin >> Prime.prime;

cout << "Here are the prime numbers: " << endl;
cin>> Primes.nPrimes;
    return 0;
}

