/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alex1
 *
 * Created on July 13, 2021, 11:17 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
struct compInfo {
    int compName;
    float address;
    float name;
    void amount;
    void signLine;
};

int main(int argc, char** argv) {
    cout << "Enter Company Name: " << endl;
    cin >> compInfo.compName;
    
    cout << "Enter the address: " << endl;
    cin >> compInfo.address;
    
    cout << "Enter the name: " << endl;
    cin >>  compInfo.name;
    
    cout << "Enter the amount: " << endl;
    cin >> compInfo.amount;
    
    cout << "Enter your signature " << endl;
    cin >> compInfo.signLine;
    return 0;
}

