/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Midterm 1 - Problem 4
 * Author: Alejandro Cruz
 *
 * Created on July 14, 2021, 4:38 PM
 */

#include <cstdlib>

using namespace std;

//Declaring variables
int num = {0, 1, 2, 3, 4, 5, 6, 7};
void sum = num*;
int main(int argc, char** argv) {
    cout << "Here are the 7 digits: " << endl;
    cin >> num;
    cout << "Here are the only 4 digits" << endl;
    cin >> sum - num;
    return 0;
}

