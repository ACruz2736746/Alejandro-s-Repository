/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Midterm 1 - Problem 5 
 * Author: Alejandro Cruz
 *
 * Created on July 15, 2021, 8:29 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << "The three numbers are 51.1875, 3.19921875, 0.2" << endl;
    cout << "The hex for three numbers are: 33.3, 3.33, and 0.33333..." << endl;
cout << "The binary for three numbers are: 110011.0011, 11.00110011, 0.001100110011..." << endl;
cout << "The octal for three numbers are: 63.14, 3.146, 0.14631463..." << endl;
            return 0;
}

