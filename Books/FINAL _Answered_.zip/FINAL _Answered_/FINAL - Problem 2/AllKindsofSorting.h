/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AllKindsofSorting.h
 * Author: alex1
 *
 * Created on July 30, 2021, 2:49 PM
 */

#ifndef ALLKINDSOFSORTING_H
#define ALLKINDSOFSORTING_H
//This class sorts arrays either ascending or descending
template<class T>
class Prob2Sort{
private:
int *index; //Index that is utilized
//in the sort
public:
Prob2Sort(){index=NULL;}; //Constructor
~Prob2Sort(){delete []index;}; //Destructor
T * sortArray(const T*,int,bool); //Sorts a single column array
T * sortArray(const T*,int,int,int,bool);//Sorts a 2 dimensional array
//represented as a 1 dim array
};


#endif /* ALLKINDSOFSORTING_H */

