/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Final - Problem 7
 * Author: Alejandro Cruz
 *
 * Created on July 31, 2021, 3:38 PM
 */

#include <iostream>

struct Item {
    Item(const char*n, double v) :
	name(n), value(v)
    {}
    const char *name;
    double value;
};


double getOrder(Item menu[])
{
    size_t i;
    double result = 0.0;	// the total of the order
    for (i=0; menu[i].name; ++i) {
	std::cout << i+1 << " - " << menu[i].name
		  << "  " << '$' << menu[i].value << '\n';
    }
    std::cout << i+1 << " - " << "End Order\n";
    
    while (true) {
	unsigned num;
	std::cout << "Enter menu item: " << std::flush;
	std::cin >> num;
	--num;			// convert from user-friendly 1 to i+1
				// to computer friendly 0 to i
	if (num > i) {
	    std::cout << "Invalid selection. Please enter a number between 1 and " << i << '\n';
	} else if (num == i) {
	    break;
	} else {
	    result += menu[num].value;
	}
    }
    return result;
}

// No need to pass total since total == bill+tax+tip
void showBill(double bill, double tax, double tip)
{
    std::cout << "Subtotal : $" << bill << '\n';
    std::cout << "     tax : $" << tax << '\n';
    std::cout << "     tip : $" << tip << '\n';
    std::cout << "   total : $"<< tax+tip+bill << '\n';
}

void changeDue(double totBill, double amtTendered)
{
    std::cout << "Your change is $" << amtTendered - totBill << '\n';
}

double getPmt(double total)
{
    while (true) {
	double amount;
	std::cout << "Enter payment amount: " << std::flush;
	std::cin >> amount;
	if (amount >= total) return amount;
	std::cout << "You must enter at least $" << total << '\n';
    }
}

int
main()
{
    constexpr double taxRate = 0.065; // tax rate on food
    constexpr double tipRate = 0.20;  // tip on pre-tax food bill

    // I'll use an array with a sentinel to indicate the end.
    // std::array would be more appropriate if you've learned about it.
    Item menu[] {
	{ "Hamburger", 6.0 },
	{ "Hot dog", 4.5 },
	{ "Peanuts", 3.75 },
	{ nullptr, 0} // MUST END WITH THIS ENTRY
    };

    std::cout.setf(std::ios::fixed, std::ios::floatfield);
    std::cout.precision(2);

    double subTotal = getOrder(menu);
    double tax = subTotal * taxRate;
    double tip = subTotal * tipRate;

    showBill(subTotal, tax, tip);
    double tendered = getPmt(subTotal+tax+tip);
    changeDue(subTotal+tax+tip, tendered);
}
