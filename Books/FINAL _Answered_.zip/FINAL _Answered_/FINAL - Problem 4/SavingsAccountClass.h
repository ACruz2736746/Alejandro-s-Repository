/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SavingsAccountClass.h
 * Author: Alejandro Cruz
 * 
 *
 * Created on July 30, 2021, 4:14 PM
 */

#ifndef SAVINGSACCOUNTCLASS_H
#define SAVINGSACCOUNTCLASS_H
class SavingAcct {
public:
SavingsAccount(float); //Constructor
void Transaction(float); //Procedure
float Total(float=0,int=0); //Savings Procedure
float TotalRecursive(float=0,int=0);
void toString(); //Output Properties
private:
float Withdraw(float); //Utility Procedure
float Deposit(float); //Utility Procedure
float Balance; //Property
int FreqWithDraw; //Property
int FreqDeposit; //Property
}
#endif /* SAVINGSACCOUNTCLASS_H */

