/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FINAL - Problem 1
 * Author: Alejandro Cruz
 *
 * Created on July 30, 2021, 2:14 PM
 */

#include <cstdlib>
#include "RandomSequence.h"
using namespace std;

/*
 * 
 */
int main() {
//Driver program to return a random sequence
char n=5;
char rndseq[]={19,34,57,79,126};
int ntimes=100000;
int Prob1Random a(n,rndseq);
for(int i=1;i<=ntimes;i++){
a.randFromSet();
}
int *x=a.getFreq();
char *y=a.getSet();
for(int i=0;i<n;i++){
cout<<int(y[i])<<" occurred "<<x[i]<<" times"<<endl;
}
cout<<"The total number of random numbers is "<<a.getNumRand()<<endl;

    return 0;
}

