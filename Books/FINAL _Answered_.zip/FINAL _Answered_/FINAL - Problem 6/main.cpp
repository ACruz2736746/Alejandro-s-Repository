/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:  Final - Problem 6
 * Author: Alejandro Cruz
 *
 * Created on July 31, 2021, 1:18 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << "5.75 in binary, octal, and hex:" << endl;
    cout << "101.11, 5.6, 5.C" << endl;
    cout << "0.9 in binary, octal, and hex:" << endl;
    cout << "0.1110011001100110011, 0.71463146314631463146, 0.E6666666666666666666" << endl;
    cout << "99.7 in binary, octal, and hex:" << endl;
    cout << "1100011.10110011001100110011, 143.54631463146314631463, " << endl;
    cout << "5.75, 0.9, and 99.7 in IEEE 754 format:" << endl;
    cout << "0x40b80000, 0x3f666666, 0x42c76666" << endl;
    return 0;
}

