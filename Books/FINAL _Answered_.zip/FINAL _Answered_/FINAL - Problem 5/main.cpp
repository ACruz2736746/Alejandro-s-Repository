/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alejandro Cruz
 *
 * Created on July 30, 2021, 6:14 PM
 */

#include <cstdlib>
#include "EmployeeClass.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << "Employee Name:" << endl;
    cin >> empInfo.Employee();
    cout << "Employee Title:" << endl;
    cin >> empInfo.Employee();
    cout << "Net Pay:" << endl;
    cin >> empInfo.getNetPay();
    cout << "Gross Pay" << endl;
    cin >> empInfo.getGrossPay();
    cout << "Hours Worked" << endl;
    cin >> empInfo.setHoursWorked(10);
    
    return 0;
}

